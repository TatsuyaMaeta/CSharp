﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob4_6
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 2;

            while(a <= 8)
            {
                Console.WriteLine("a = {0}", a);
                a += 2;
            }
        }
    }
}
