﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob4_7
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int a = 2; a <= 8; a += 2)
            {
                Console.WriteLine("a = {0}", a);
            }
        }
    }
}
