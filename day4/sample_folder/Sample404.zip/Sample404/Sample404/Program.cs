﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample404
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            do
            {
                Console.Write(i + " ");
                i++;
            } while (i <= 5);
            Console.WriteLine();
        }
    }
}
