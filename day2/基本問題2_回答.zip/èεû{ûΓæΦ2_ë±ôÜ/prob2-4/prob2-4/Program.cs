﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob2_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("文字列を入力：");
            string s = Console.ReadLine();
            Console.WriteLine("入力された文字列：{0}", s);
        }
    }
}
