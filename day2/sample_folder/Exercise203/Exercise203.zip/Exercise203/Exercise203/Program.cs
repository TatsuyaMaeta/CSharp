﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise203
{
    class Program
    {
        static void Main(string[] args)
        {
            //  文字列型変数s1, s2, s3を用意しなさい。
            string s1, s2, s3;
            //  s1に「あいう」と代入しなさい。
            s1 = "あいう";
            //  s2に「えお」と代入しなさい。
            s2 = "えお";
            //  s3にs1とs2を結合した値を代入しなさい。
            s3 = s1 + s2;
            //  s3を表示しなさい。
            Console.WriteLine(s3);
        }
    }
}
