﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise302
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = Console.ReadLine();
            string s2 = Console.ReadLine();
            if(s1 == "hello" && s2 == "world")
            {
                Console.WriteLine("Good!");
            }
            else
            {
                Console.WriteLine("helloworld please!");
            }
        }
    }
}
